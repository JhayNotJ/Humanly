HUMANLY Knowledge v1.1

Preserves 402 original v1.0 educational records unchanged and adds 30 official-source-reviewed bilingual articles visible to users and 16 safety/medical educational drafts ON HOLD (not available in search).

Green Verified is limited to article source comparison; NOT independent expert approval. Safety drafts remain orange. Review scopes and source URLs are in v11_source_verification and ARTICLE_REVIEW.json.

Internal SQLite filename remains humanly-knowledge-v1.db for compatibility with current Android installer. Database metadata version is 1.1.
