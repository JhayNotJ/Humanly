# HUMANLY Knowledge Editorial Status

The source register documents authoritative organizations and source links. HUMANLY summaries are original and have NOT been independently professionally reviewed or endorsed by those organizations. The 478 prior entries also remain draft content. Do not label as professionally reviewed.

- WHO: Hand hygiene in community settings — https://www.ncbi.nlm.nih.gov/books/NBK619535/
- WHO: Five moments for hand hygiene — https://www.who.int/publications/m/item/five-moments-for-hand-hygiene
- Ready.gov: Emergency supply list — https://www.ready.gov/kit
- Ready.gov: Earthquakes — https://www.ready.gov/earthquakes
- Ready.gov: Floods — https://www.ready.gov/floods
- CFPB: Emergency savings — https://www.consumerfinance.gov/an-essential-guide-to-building-an-emergency-fund/
- consumer.gov: Making a budget — https://consumer.gov/your-money/making-budget
- PHIVOLCS: Earthquake preparedness — https://www.phivolcs.dost.gov.ph/
- PAGASA: Tropical cyclone information — https://www.pagasa.dost.gov.ph/
- MedlinePlus: Health information — https://medlineplus.gov/
- NIST: Cybersecurity guidance — https://www.nist.gov/cybersecurity
- FTC: Consumer advice — https://consumer.ftc.gov/
